package Excepciones;

public class EntidadNoExiste extends Exception {
    public EntidadNoExiste(String message) {
        super(message);
    }
}
