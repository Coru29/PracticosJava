package tads.stack;

public class EmptyStackException extends Exception {
}
